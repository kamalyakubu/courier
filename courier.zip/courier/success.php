<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style>
<span class="style1">SuccessFull  <?php echo $_GET['cid'];?></span> 